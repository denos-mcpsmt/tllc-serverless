
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'denos1337',
  applicationName: 'tllc-serverless',
  appUid: 'cNpCYCXMv6xcK2WbSF',
  orgUid: '86bed34c-7ee5-43d7-bc34-1fa46b41b3bf',
  deploymentUid: 'e057baec-d44c-4a0b-ae85-88bc42099d20',
  serviceName: 'tllc',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.0.5',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'tllc-dev-createCustomer', timeout: 6 };

try {
  const userHandler = require('./createCustomer.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createCustomer, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}